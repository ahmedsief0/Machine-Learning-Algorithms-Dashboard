import json
import pandas as pd

import seaborn as sns
import matplotlib.pyplot as plt

import streamlit as st

st.title("📊 Machine Learning Models Performance Dashboard")

# قراءة الملفات
with open("results_spam.json", "r") as f:
    spam_results = json.load(f)

with open("results.json", "r") as f:
    price_results = json.load(f)

with open("results_DOC.json", "r") as f:
    doc_results = json.load(f)

# نجهز dict موحد
all_results = {
    "Spam Detection": spam_results["Spam"],
    "Price Prediction": price_results["Price Prediction"],
    "Document Classification": doc_results["DOC_Class"],
}

# نفكهم في list عشان نحولها DataFrame
records = []
for proj, res in all_results.items():
    for alg, acc in res.items():
        records.append({"Algorithm": alg, "Project": proj, "Test Accuracy": acc})

df = pd.DataFrame(records)

# واجهة اختيار المشروع
project = st.selectbox("Select Project", list(all_results.keys()))

# واجهة اختيار الخوارزميات
algorithms = st.multiselect(
    "Select Algorithms",
    options=df[df["Project"] == project]["Algorithm"].unique()
)

# فلترة الداتا حسب الاختيارات
filtered_df = df[(df["Project"] == project) & (df["Algorithm"].isin(algorithms))]

st.subheader(f"Results {project}")
st.dataframe(filtered_df)

# رسم الـ Bar Chart للخوارزميات المختارة
if not filtered_df.empty:
    st.subheader("📊 Selected algorithms for Bar chart")
    st.bar_chart(filtered_df.set_index("Algorithm")["Test Accuracy"])
else:
    st.info("Choose at least one algorithm and one project to display the chart.")
